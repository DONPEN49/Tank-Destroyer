#pragma once
#include	<DirectXMath.h>

void drawaxis(DirectX::XMFLOAT4X4 mtx, float length, DirectX::XMFLOAT3 pos);
#include "Manager_Billboard.h"

void Manager_Billboard::LoadAllBillboard() {
	LoadBillboard("assets/Texture/Particle01.png");
	LoadBillboard("assets/Texture/Smoke.png");
	LoadBillboard("assets/Texture/explosion2.png");
	LoadBillboard("assets/Texture/tanksmoke.png");
}
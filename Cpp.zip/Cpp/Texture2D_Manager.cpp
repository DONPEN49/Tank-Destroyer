#include "Texture2D_Manager.h"

void Texture2D_Manager::AllTexture2DLoad() {
	//�e�N�X�`��
	LoadTexture2D("assets/texture/reda.png");
	LoadTexture2D("assets/texture/EPoint.png");
	LoadTexture2D("assets/texture/play.png");
	LoadTexture2D("assets/texture/exit.png");
	LoadTexture2D("assets/texture/title.png");
	LoadTexture2D("assets/texture/se.png");
	LoadTexture2D("assets/texture/hp_2.png");
	LoadTexture2D("assets/texture/damage.png");
	LoadTexture2D("assets/texture/Closs.png");
	LoadTexture2D("assets/texture/speed.png");
	LoadTexture2D("assets/texture/power.png");
	LoadTexture2D("assets/texture/range.png");
	LoadTexture2D("assets/texture/red.png");
	LoadTexture2D("assets/texture/green.png");
	LoadTexture2D("assets/texture/blue.png");
	
}